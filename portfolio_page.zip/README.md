# Portfolio Page

This is my personal portfolio page showcasing my projects and skills.

## Features

- Showcase of projects
- Contact form integration
- Links to GitHub and LinkedIn

## Installation

Clone the repository and open the `index.html` file in a browser.

```bash
git clone https://github.com/officialmelvinp/portfolio_page.git
cd portfolio_page
